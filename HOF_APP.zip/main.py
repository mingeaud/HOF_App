##################################################################
#
#   David Mingeuad
#   CS361 Fall 2021
#   Final Project - Baseball Hall of Fame Lookup App - Main Window
#
##################################################################
from tkinter import *
import json
from Second_Window import *
import requests


class App():
    """
    Creates the main window for the app where the players are found through a search of locally supplied names
    and the name is sent to the microservice to revice additional information to present in a second pop up window
    """

    def __init__(self, parent):

        # Creates the main window and gives it a title 
        self.parent = parent
        self.parent.title("Baseball Hall of Fame Search")

        # initializes variables
        self.initialize_variables()
        
        # Imports the player's names from a local file to fill the search boxes
        self.import_names()

        # sort the list of players to make finding them in the narrowed down list easier for the user
        self.sort_players()

        # Creates the label frame that contains the check boxes and the text input fields
        self.create_label_frame()

        # creates the checkboxes used to narrow down the type of person
        self.create_check_boxes()

        # creates the text input boxes for first and last name
        self.create_text_inputs()

        # creates the search button and adds its functionality
        self.create_search_button()

        # Creates the Drop Down Menu
        self.create_drop_down()
        
        # creates the close button
        self.create_close_button()


    def initialize_variables(self):
        """
        Initializes variables to clean up the cluttered __init__() function
        """

        # Style constants to change the look and feel consistantly for each widget
        self._style = ('Arial',13)
        self._frame_text_style = ('Arial',20)

        # initializing the list of players that will populate the drop down menu
        self._drop_down_list = ["Select Player"]

        # Initializing variables for the check boxes in the search area
        self._var = []
        for x in range(0,4):
            self._var += [IntVar()]

        # initialize the check box titles for searching
        self._titles = ["Player","Manager","Umpire","Pioneer/Executive"]


    def import_names(self):
        """
        Imports the names from a local file to fill the search fields and to narrow
        down the results after the user narrows dow the search criteria
        """
        file_name = "players_names.json"
        with open(file_name, 'r') as infile:
            self._players = json.load(infile) 
    
    
    def sort_players(self):
        """
        Uses an insertion sort on last name after the locally stored list of players
        is imported at startup
        """
        for index in range(1, len(self._players)):
            temp = self._players[index]
            pos = index - 1
            while pos >= 0 and self._players[pos].get("Last") > temp.get("Last"):
                self._players[pos + 1] = self._players[pos]
                pos -= 1
            self._players[pos + 1] = temp

           
    def create_label_frame(self):
        """
        Creates the label frame that contains the check boxes and the text
        inputs for first and last name to narrow down the search
        """
        
        self._label_frame = LabelFrame(self.parent, text = "Search", padx = 10, pady = 10)
        self._label_frame.configure(font=(self._frame_text_style))
        label_text = 'Check which types of player to search for:'
        self._label = Label(self._label_frame, text = label_text, font=(self._style))
        self._label.grid(row = 0, column = 0, columnspan = 3, sticky = W)


    def create_check_boxes(self):
        """
        Creates the checkboxes in the search frame
        """

        self._check_button = []
        check_column = 0
        for x in range(0, 4):
            self._check_button = Checkbutton(self._label_frame, text = self._titles[x])
            self._check_button.configure(variable = self._var[x], font=(self._style))
            self._check_button.grid(row = 1, column = check_column, sticky = W)
            check_column += 1


    def create_text_inputs(self):
        """
        Creates the name search input boxes
        """
        
        self._label = Label(self._label_frame, text = "First Name: ", font=(self._style))
        self._label.grid(row = 2, column = 0, columnspan = 1, sticky = W)
        self._text_box1 = Entry(self._label_frame)
        self._text_box1.grid(row = 2, column = 1)
        self._label = Label(self._label_frame, text = "Last Name: ",font=(self._style))
        self._label.grid(row = 2, column = 2, columnspan = 1, sticky = W)
        self._text_box2 = Entry(self._label_frame)
        self._text_box2.grid(row = 2, column = 3)


    def create_search_button(self):
        """
        Creates the search button, adds it to the main window and sends the click
        action to self.search_button()
        """

        self._button1 = Button(self._label_frame, text = "Search")
        self._button1.configure(command=self.search_button,font=(self._style))
        self._button1.grid(row = 3, column = 0, sticky = W)
        self._label_frame.pack(fill = X)


    def create_drop_down(self):
        """
        Creates the drop down menu and adds the Select Player button
        """

        # adds the drop down menu
        self._label = Label(self.parent, text = "Select which player you're looking for:")
        self._label.configure(font=(self._style))
        self._label.pack()
        self._clicked = StringVar()
        self._clicked.set("")
        self._drop_down_menu = OptionMenu(self.parent , self._clicked , *self._drop_down_list)
        self._drop_down_menu.config(width = 25)
        self._drop_down_menu.pack()

        # adds the Select Player button
        self._button2 = Button(self.parent, text = "Select Player", command=self.select_button)
        self._button2.configure(font=(self._style))
        self._button2.pack()


    def create_close_button(self):
        """
        Creates the close button and send the click action to self.close_window()
        """
        
        self._button3 = Button(self.parent, text = "Close", command = self.close_window)
        self._button3.configure(font=(self._style))
        self._button3.pack(side = LEFT, padx = 10, pady = 10)


    def search_button(self):
        """
        Handles when the search button is pushed. This cycles through the complete list
        of players and matches it to the search criteria. When the search button is
        pushed, the drop down list will be populated with only these results.
        """

        # reset the drop down menu to display the instructions and reset the list of players
        self._clicked.set("Choose Name from List")
        self._drop_down_list = []


        # get the player's first and last names that the user input into the
        # search boxes
        first_name = self._text_box1.get().upper()
        last_name = self._text_box2.get().upper()


        # cycles through the entire list of player names and matches it to the
        # checkbox results and partial text strings from the search input boxes
        for player in self._players:
            first = player.get("First").upper()
            last = player.get("Last").upper()
            for x in range(0, 4):
                if self._var[x].get() == 1 and first_name in first and last_name in last:
                    if player.get("Inducted As") == self._titles[x]:
                        self._drop_down_list += [player.get("First") + " " + player.get("Last")]
    

        # Populates the drop down menu with the narrowed down list of players
        menu = self._drop_down_menu["menu"]
        menu.delete(0,'end')
        for x in self._drop_down_list:
            menu.add_command(label=x, command=lambda value=x: self._clicked.set(value))


    def select_button(self):
        """
        Process the player after they have been selected from the drop down menu 
        """

        # get the selected player name from the drop down menu
        full_name = self._clicked.get()


        if full_name != "Choose Name from List":
            # send the player name to the microservice for additional information
            player_data = requests.get("http://127.0.0.1:5001/get_player/{}".format(full_name))
            player = player_data.json()

            # append the players name and open a second window to show the players
            # information        
            player['Name'] = full_name
            Second_Window(self.parent, player, self._style)
                

    
    def close_window(self):
        """
        Close the entire appliation when the close button is selected.
        """
        self.parent.destroy()


# create the app and start the mainloop
root = Tk()
App(root)
root.mainloop()

