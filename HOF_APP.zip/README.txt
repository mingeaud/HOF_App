INTRODUCTION
------------
This is an application for displaying members
 of the baseball hall of fame using Python and Tkinter. 
The data is being provided by a colleagues microservice using a RESTFUL API.


REQUIREMENTS
------------
Python v3.0


RECOMMENDED MODULES
-------------------
- tkinter
- json
- requests
- PIL
- os
- io


INSTRUCTIONS
-------------------
To start the microservice, open a command window and run:
python data_service.py

To start the application, open a new command window and run:
python main.py
