##################################################################
#
#   David Mingeuad
#   CS361 Fall 2021
#   Final Project - Baseball Hall of Fame Lookup App - Pop Up Window
#
##################################################################
from tkinter import *
from PIL import ImageTk, Image
import os
import requests
from io import BytesIO

class Second_Window():
    """
    A pop up that shows the selected players information
    """

    def __init__(self, parent, player, style):
        self._window = Toplevel()
        self._window.title("Selected Player Info")
        self._window.minsize(300,400)
        self._player = player
        self._style = style

        # Initializes the label frames
        self._label_frame = Frame(self._window)
        self._label_frame_2 = Frame(self._window)

        # gets the pitcure from the URL and displays it
        self.display_picture()

        # fills in the empty text fields for people that weren't voted for
        self.clean_blanks()

        # prints the biographical info in self._label_frame_2
        self.print_info()

        # displays the two label frames
        self._label_frame.pack()
        self._label_frame_2.pack()

        # adds the back button to the bottom of the window
        self._button = Button(self._window, text = "Back", command = self.close_window,font = (self._style))
        self._button.pack()

        
    def display_picture(self):
        """
        Gets the pitcure from the given URL and prints it to the first label frame
        """

        # gets the players picture from the URL in the recieved JSON
        response = requests.get(self._player.get('picture'))

        # If the response was good, parse the image from the GET request and
        # display it
        if response.status_code == 200:
            img_data = response.content
            temp_image = Image.open(BytesIO(img_data))
            temp_image = temp_image.resize((120,180))
            img = ImageTk.PhotoImage(temp_image)
            my_label = Label(self._label_frame, image = img)
            my_label.image = img
            my_label.pack(side="bottom", fill="both", expand="yes")


    def clean_blanks(self):
        """
        Some people weren't voted for and the blank spot looked odd so this fills
        in the open space with N/A
        """
                
        if self._player.get('Ballot Percent') == "":
            self._player['Ballot Percent'] = "N/A"
        if self._player.get('Votes') == "":
            self._player['Votes'] = "N/A"


    def print_info(self):
        """
        Displays the information from the JSON file
        """
        
        # this list is to print the dictionary entries in a particular order in
        # a for loop
        titles = ["Name","Year","Life Span","Voted By","Inducted As", "Votes","% of Ballots"]
        values = ["Name","Year","Lifespan","Voted By","Position", "Votes","Ballot Percent"]


        # The person's biographical info can be printed with a for loop using
        # the titles and values lists above
        counter = 0
        for stat in values:
            label = Label(self._label_frame_2, text = titles[counter] + ": ", font = (self._style))
            label.grid(row = counter, column = 0, sticky = W)
            label = Label(self._label_frame_2, text = self._player.get(stat), font = (self._style))
            label.grid(row = counter, column = 1, sticky = W)
            counter += 1


    def close_window(self):
        """
        closes the pop up when the close button is pressed
        """
        self._window.destroy()


